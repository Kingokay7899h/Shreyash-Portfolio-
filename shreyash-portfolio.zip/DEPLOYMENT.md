# 🚀 Deploying Shreyash Desai Portfolio to Netlify via GitHub

## Overview
This guide walks you through deploying your cinema-quality portfolio to Netlify using GitHub for automatic deployments.

## 📋 Prerequisites
- GitHub account
- Netlify account (free)
- Your portfolio files (already created)

## Step 1: Upload to GitHub

### 1.1 Create GitHub Repository
1. Go to [GitHub.com](https://github.com) and sign in
2. Click the "+" icon → "New repository"
3. Repository name: `shreyash-portfolio`
4. Description: `Cinema-quality developer portfolio for Shreyash Desai`
5. Make it **Public** (recommended for portfolio)
6. ✅ Check "Add a README file"
7. Click "Create repository"

### 1.2 Upload Your Files
**Method A: GitHub Web Interface (Easiest)**
1. In your new repository, click "uploading an existing file"
2. Drag and drop all your project files EXCEPT:
   - `node_modules/` folder
   - `.git/` folder  
   - Any `.log` files
3. Write commit message: "Initial portfolio upload"
4. Click "Commit changes"

**Method B: Git Commands (if you have Git installed)**
```bash
git clone https://github.com/yourusername/shreyash-portfolio.git
cd shreyash-portfolio
# Copy all your project files here
git add .
git commit -m "Initial portfolio upload"  
git push origin main
```

## Step 2: Connect to Netlify

### 2.1 Create Netlify Account
1. Go to [Netlify.com](https://netlify.com)
2. Click "Sign up" → "Sign up with GitHub"
3. Authorize Netlify to access your GitHub

### 2.2 Deploy from GitHub
1. In Netlify dashboard, click "Add new site" → "Import an existing project"
2. Click "Deploy with GitHub"
3. Choose your `shreyash-portfolio` repository
4. Configure build settings:
   ```
   Build command: npm run build:client
   Publish directory: client/dist
   ```
5. Click "Deploy site"

## Step 3: Custom Domain (Optional but Recommended)

### 3.1 Set Up Custom Domain
1. In your Netlify site dashboard → "Domain management"
2. Click "Add custom domain"  
3. Enter your domain (e.g., `shreyashdesai.com`)
4. Follow DNS setup instructions

### 3.2 Free Netlify Subdomain
If you don't have a custom domain:
1. Go to "Domain management" → "Options" → "Edit site name"
2. Change from random name to: `shreyash-desai-portfolio`
3. Your site will be: `https://shreyash-desai-portfolio.netlify.app`

## Step 4: Environment Configuration

### 4.1 Environment Variables (if needed)
1. In Netlify dashboard → "Site configuration" → "Environment variables"
2. Add any required variables:
   ```
   VITE_SITE_URL=https://your-domain.com
   VITE_CONTACT_EMAIL=shreyashdesai60@gmail.com
   ```

## Step 5: Optimize for Production

### 5.1 Performance Settings
In Netlify dashboard:
1. "Site configuration" → "Build & deploy" → "Post processing"
2. Enable:
   - ✅ Asset optimization  
   - ✅ Bundle CSS
   - ✅ Minify CSS
   - ✅ Minify JS
   - ✅ Image optimization

### 5.2 Security Headers
1. Create `_headers` file in your `client/public` folder:
```
/*
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  X-XSS-Protection: 1; mode=block
  Strict-Transport-Security: max-age=31536000; includeSubDomains
```

## Step 6: Continuous Deployment

### 6.1 Automatic Updates
- Every time you push changes to GitHub, Netlify automatically rebuilds
- Build status appears in Netlify dashboard
- Failed builds get email notifications

### 6.2 Preview Deployments
- Pull requests create preview URLs
- Test changes before merging to main branch

## 🎯 Final Checklist

- [ ] Repository created on GitHub
- [ ] All project files uploaded (except node_modules)
- [ ] Netlify site connected to GitHub repo
- [ ] Build settings configured correctly
- [ ] Custom domain set up (optional)
- [ ] SSL certificate enabled (automatic)
- [ ] Performance optimizations enabled

## 📱 Project Structure for Deployment

Your uploaded files should include:
```
shreyash-portfolio/
├── client/                 # Frontend React app
├── server/                 # Backend Express server  
├── shared/                 # Shared TypeScript types
├── package.json           # Dependencies
├── netlify.toml          # Netlify configuration
├── vite.config.ts        # Vite build config
├── tailwind.config.ts    # Tailwind setup
├── tsconfig.json         # TypeScript config
└── README.md             # Project documentation
```

## 🔧 Troubleshooting

### Build Fails?
1. Check build logs in Netlify dashboard
2. Ensure all dependencies in package.json
3. Verify build command: `npm run build:client`
4. Check Node.js version (should be 18+)

### Site Not Loading?
1. Check publish directory: `client/dist`
2. Verify _redirects file for SPA routing
3. Check browser console for errors

### Need Help?
- Netlify docs: https://docs.netlify.com
- GitHub docs: https://docs.github.com
- Contact: shreyashdesai60@gmail.com

---

🎉 **Congratulations!** Your Shreyash Desai portfolio is now live on the internet with professional hosting and automatic deployments!