import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-midnight text-ghost flex items-center justify-center">
      <div className="text-center">
        <div className="text-6xl font-bold holographic-text mb-8">404</div>
        <h1 className="text-3xl font-bold text-electric mb-4">Page Not Found</h1>
        <p className="text-lg text-silver mb-8">
          The page you're looking for doesn't exist.
        </p>
        <Button asChild className="bg-aurora text-midnight px-8 py-4 rounded-full font-semibold hover:scale-105 transition-all duration-300">
          <Link href="/">Return Home</Link>
        </Button>
      </div>
    </div>
  );
}